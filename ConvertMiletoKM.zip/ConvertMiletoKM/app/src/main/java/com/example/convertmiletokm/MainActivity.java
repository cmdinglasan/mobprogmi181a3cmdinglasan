package com.example.convertmiletokm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button buttonConvertMilestoKM = (Button) findViewById(R.id.buttonConvertMilestoKM2);
        buttonConvertMilestoKM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText textMiles = (EditText) findViewById(R.id.textMiles);
                EditText textKM = (EditText) findViewById(R.id.textKM);
                double vMiles = Double.valueOf(textMiles.getText().toString());
                double vKM = vMiles / 0.61237;
                DecimalFormat formatVal = new DecimalFormat("##.##");
                textKM.setText(formatVal.format(vKM));
            }
        });
        Button buttonConvertKMtoMiles = (Button) findViewById(R.id.buttonConvertKMtoMiles);
        buttonConvertKMtoMiles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText textMiles = (EditText) findViewById(R.id.textMiles);
                EditText textKM = (EditText) findViewById(R.id.textKM);
                double vKM = Double.valueOf(textKM.getText().toString());
                double vMiles = vKM * 0.61237;
                DecimalFormat formatVal = new DecimalFormat("##.##");
                textMiles.setText(formatVal.format(vMiles));
            }
        });
    }
}
